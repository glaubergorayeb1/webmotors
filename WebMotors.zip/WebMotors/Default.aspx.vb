﻿Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Response.Redirect("Incluir.aspx")
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        Session("ID_Anuncio") = ""
        Label1.Text = ""
        Session("ID_Anuncio") = GridView1.SelectedDataKey.Value
        Label1.Visible = True
        Label1.Text = "Item " & Session("ID_Anuncio") & " selecionado. Clique em ATUALIZAR para alterar seus dados ou em REMOVER para excluir o item."
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("Atualizar.aspx")
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        InsertReg("delete  [dbo].[tb_AnuncioWebmotors] where id='" & Session("ID_Anuncio") & "'")
        Label1.Text = ""
        DS_Anuncios.SelectCommand = "SELECT * FROM [tb_AnuncioWebmotors]"
        GridView1.DataBind()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim camposql As String

        If Rbl_Pesquisa.SelectedIndex = 0 Then
            camposql = "where marca like '%" & txt_pesquisa.Text & "%' "
        ElseIf Rbl_Pesquisa.SelectedIndex = 1 Then
            camposql = "where modelo like '%" & txt_pesquisa.Text & "%' "
        ElseIf Rbl_Pesquisa.SelectedIndex = 2 Then
            camposql = "where ano like '%" & txt_pesquisa.Text & "%' "
        End If

        DS_Anuncios.SelectCommand = "SELECT * FROM [tb_AnuncioWebmotors] " & camposql & ""
        GridView1.DataBind()
    End Sub
End Class