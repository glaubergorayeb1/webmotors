﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' As Informações Gerais sobre um assembly são controladas por meio do 
' conjunto de atributos a seguir. Altere esses valores de atributo para modificar as informações
' associadas a um assembly.

' Verificar os valores dos atributos do conjunto
<Assembly: AssemblyTitle("WebMotors")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("WebMotors")>
<Assembly: AssemblyCopyright("Copyright ©  2022")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'A GUID a seguir será referente à ID do typelib se este projeto for exposto ao COM
<Assembly: Guid("f3deedec-d3f9-4ee1-b74d-1a46d8395e8b")>

' As informações de versão de um assembly consistem nos quatro valores a seguir:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' É possível especificar todos os valores ou utilizar como padrão os Números da Versão e de Revisão 
' usando o '*' como mostrado abaixo:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
