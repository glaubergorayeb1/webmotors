﻿Imports System.Net
Imports Newtonsoft.Json

Public Class Incluir
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            marca()
        End If
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("default.aspx")
    End Sub

    Private Sub marca()
        Dim url As String = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Make"
        Dim cli = New WebClient()
        cli.Headers(HttpRequestHeader.ContentType) = "application/json;charset=UTF-8"

        Dim response As String = cli.DownloadString(url)
        Dim jj As Object = JsonConvert.DeserializeObject(Of Object)(response)

        ddl_marca.Items.Clear()
        ddl_marca.Items.Add("Selecione...")
        Try

            Dim total_itens As Integer = DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Count
            For i_itens As Integer = 0 To total_itens - 1
                ddl_marca.Items.Add(DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("ID").ToString & " - " & DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("Name").ToString)
            Next

        Catch ex As Exception
            ' in case the structure of the object is not what we expected.

        End Try
    End Sub

    Private Sub modelo()
        Dim array As Array = Split(ddl_marca.Text, " - ")


        Dim url As String = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Model?MakeID=" & array(0)
        Dim cli = New WebClient()
        cli.Headers(HttpRequestHeader.ContentType) = "application/json;charset=UTF-8"

        Dim response As String = cli.DownloadString(url)
        Dim jj As Object = JsonConvert.DeserializeObject(Of Object)(response)


        Try
            ddl_Modelo.Items.Add("Selecione...")
            Dim total_itens As Integer = DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Count
            For i_itens As Integer = 0 To total_itens - 1
                ddl_Modelo.Items.Add(DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("ID").ToString & " - " & DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("Name").ToString)

            Next

        Catch ex As Exception
            ' in case the structure of the object is not what we expected.

        End Try
    End Sub

    Private Sub versao()
        Dim array As Array = Split(ddl_Modelo.Text, " - ")


        Dim url As String = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Version?ModelID=" & array(0)
        Dim cli = New WebClient()
        cli.Headers(HttpRequestHeader.ContentType) = "application/json;charset=UTF-8"

        Dim response As String = cli.DownloadString(url)
        Dim jj As Object = JsonConvert.DeserializeObject(Of Object)(response)

        ddl_versao.Items.Add("Selecione...")
        Try

            Dim total_itens As Integer = DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Count
            For i_itens As Integer = 0 To total_itens - 1
                ddl_versao.Items.Add(DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("ID").ToString & " - " & DirectCast(jj, Newtonsoft.Json.Linq.JContainer).Item(i_itens).Item("Name").ToString)

            Next

        Catch ex As Exception
            ' in case the structure of the object is not what we expected.

        End Try
    End Sub

    Protected Sub ddl_marca_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_marca.SelectedIndexChanged
        ddl_Modelo.Items.Clear()
        modelo()
    End Sub

    Protected Sub ddl_Modelo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddl_Modelo.SelectedIndexChanged
        ddl_versao.Items.Clear()
        versao()
    End Sub


    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim marca As Array = Split(ddl_marca.Text, " - ")
        Dim modelo As Array = Split(ddl_Modelo.Text, " - ")
        Dim versao As Array = Split(ddl_versao.Text, " - ")


        InsertReg("INSERT INTO [dbo].[tb_AnuncioWebmotors]
           ([marca]
           ,[modelo]
           ,[versao]
           ,[ano]
           ,[quilometragem]
           ,[observacao])
     VALUES
           ('" & marca(1) & "'
           ,'" & modelo(1) & "'
           ,'" & versao(1) & "'
           ,'" & ddl_Ano.Text & "'
           ,'" & txt_KM.Text & "'
           ,'" & txt_obs.Text & "')")

        Response.Redirect("default.aspx")
    End Sub
End Class