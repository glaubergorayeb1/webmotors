﻿Module Module1

    Public sqlconn As String = "packet size=4096;User ID=sa;Password=teste123.;data source=localhost;persist security info=true;initial catalog=teste_webmotors;Connect Timeout=0"

    Public Sub InsertReg(ByVal SQL As String)
        Dim objCon6 As New SqlClient.SqlConnection(sqlconn)
        Dim objCmd6 As New SqlClient.SqlCommand(SQL, objCon6)
        objCmd6.CommandTimeout = 0
        objCon6.Open()
        objCmd6.ExecuteNonQuery()
        objCmd6.Dispose()
        objCmd6 = Nothing
        objCon6.Close()
        objCon6.Dispose()
        objCon6 = Nothing
    End Sub
End Module
