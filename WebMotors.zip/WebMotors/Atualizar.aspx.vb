﻿Imports System.Data.SqlClient

Public Class Atualizar
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            lbl_idVenda.Text = Session("ID_Anuncio")
            carregar()
        End If
    End Sub

    Private Sub carregar()
        Dim Conn As New SqlConnection(sqlconn)
        Dim Cmd As New SqlCommand(" SELECT  
      [marca]
      ,[modelo]
      ,[versao]
      ,[ano]
      ,[quilometragem]
      ,[observacao]
  FROM [teste_webmotors].[dbo].[tb_AnuncioWebmotors]
  where [ID]='" & Session("ID_Anuncio") & "'", Conn)
        Conn.Open()
        Dim Rdr As SqlDataReader = Cmd.ExecuteReader
        While Rdr.Read

            txt_marca.Text = (Rdr.Item(0).ToString)
            txt_modelo.Text = (Rdr.Item(1).ToString)
            txt_vesao.Text = (Rdr.Item(2).ToString)
            ddl_Ano.Text = (Rdr.Item(3).ToString)
            txt_KM.Text = (Rdr.Item(4).ToString)
            txt_obs.Text = (Rdr.Item(5).ToString)

        End While

        Rdr.Close()
        Rdr = Nothing
        Cmd.Dispose()
        Cmd = Nothing
        Conn.Close()
        Conn.Dispose()
        Conn = Nothing
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Response.Redirect("default.aspx")
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        InsertReg("UPDATE [dbo].[tb_AnuncioWebmotors]
   SET[ano] ='" & ddl_Ano.Text & "'
      ,[quilometragem] = '" & txt_KM.Text & "'
      ,[observacao] = '" & txt_obs.Text & "'
 WHERE ID='" & Session("ID_Anuncio") & "'")

        Response.Redirect("default.aspx")

    End Sub
End Class